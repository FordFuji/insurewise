<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head><?php require('inc_header.php'); ?>
</head>
<?php require('inc_topmenu.php'); ?>

<body class="bluelight">

    <section id="compulsorypage" class="wrapperPages">
        <div class="container-fluid g-0 overflow-hidden">
            <div class="row g-0" data-aos="fade-down" data-aos-once="true">
                <div class="col-md-6 col-lg-4">
                    <div class="captionBanner">
                        <div class="dividepage mb-5">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#"><i class="fi fi-rr-home"></i> </a></li>
                                    <li class="breadcrumb-item active" aria-current="page">ประกันภัยขนส่งสินค้า</li>
                                </ol>
                            </nav>
                        </div>
                        <h1>ประกันภัยขนส่งสินค้า</h1>
                        <p>เพื่อเพิ่มความมั่นใจให้กับเจ้าของสินค้าที่กำลังจะนำส่งสินค้านั้นๆ
                            ไปยังจุดหมายปลายทาง
                        </p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-8">
                    <div class="bannerside">
                        <img src="images/banner_transport.png" alt="">
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid g-0 overflow-hidden">
            <div class="wrapper_pad">
                <div class="row mt-5 mb-5">
                    <div class="col">
                        <div class="titleTopic">
                            <h2>ทำความรู้จักกับประกันภัยขนส่งสินค้า</h2>
                        </div>
                        <div class="contentbody">
                            ประกันภัยขนส่งสินค้าคือกรมธรรม์ประกันที่คุ้มครองความสูญเสียหรือความเสียหายของสินค้าที่นำเข้าหรือส่งออกโดยทางบก
                            ที่เกิดขึ้นในระหว่างการขนส่งสินค้า โดยคุ้มครองระหว่างการขนส่งสินค้าทางบกทั้งภายในประเทศไทย
                            และยังข้ามแดนไปถึงประเทศ ลาว พม่า จีน กัมพูชา ทั่วประเทศโดยไม่จำกัดระยะทาง
                            และไม่ว่าจะเป็นรถชนิดไหนเราก็รับประกัน เช่น รถกะบะตู้แห้ง รถกะบะตู้เย็น รถบรรทุก รถหัวลาก
                            รถหางพ่วง เป็นต้น เพียงมีทะเบียนรถไทยก็สามารถซื้อความคุ้มครองกับเราได้
                            โดยกรมธรรม์มีความคุ้มครอง 1 ปี เบี้ยเริ่มต้นเพียง 2,685.70 บาท และทาง NSI นำสินประกันภัย
                            สามารถให้คุณซื้อเป็นแบบรายเที่ยวได้อีกด้วย

                        </div>
                    </div>
                </div>
            </div>


            <div class="wrapper_pad">
                <div class="row mt-5">
                    <div class="col titleTopic">
                        <h4>ความคุ้มครอง</h4>
                    </div>
                </div>
                <div class="row mt-5">
                    <div class="col">
                        <div class="contentbody">
                            คุ้มครองตามเงื่อนไขการรับประกันภัยความรับผิดของผู้ขนส่ง ความสูญหาย
                            หรือเสียหายของของที่ผู้เอาประกันภัยรับขน ซึ่งเกิดขึ้นในระหว่าง การขนส่งและ
                            ในระหว่างระยะเวลาประกันภัย ตั้งแต่เมื่อของได้บรรทุกขึ้นไปยังยานพาหนะขนส่ง
                            จนกระทั่งส่งมอบของและเป็นการขนส่ง โดยยานพาหนะขนส่งที่ได้ระบุไว้ในตาราง
                            กรมธรรม์ประกันภัย
                            บริษัท วิริยะประกันภัย จำกัด (มหาชน) <br><br>
                            ความคุ้มครองของกรมธรรม์
                            ซึ่งกระทำโดยผู้เอาประกันภัยหรือตัวแทนหรือลูกจ้างของผู้เอาประกันภัย
                            ㆍ คุ้มครองความสูญเสียหรือเสียหายจากการลักทรัพย์ การชิงทรัพย์
                            การปลันทรัพย์ในระหว่างการขนส่ง โดยปรากฎร่องรอยความเสียหายและ
                            จะต้องเป็นการกระทำโดยบุคคลที่ไม่ใช่ผู้เอาประกันภัย หรือลูกจ้าง หรือ
                            ตัวแทน ของผู้เอาประกันภัย <br><br>
                            . ความเสียหายของสินค้าจากการเปียกน้ำฝน เนื่องจากสาเหตุผ้าใบ
                            โดนกิ่งไม้หรือโดนของมีคมหรือโดนวัตถุอื่นๆ ทำให้เกิดการฉีกขาด น้ำฝนรั่วซึม
                            เข้าผ้าใบหรือตามขอบตะเข็บผ้าใบ รวมถึงน้ำฝนรั่วซึมเข้าตู้คอนเทนเนอร์
                            ทั้งนี้ไม่คุ้มครองความสูญเสียหรือเสียหายอันเกิดจากผ้าใบ หรือตู้คอนเทนเนอร์
                            เสื่อมสภาพ มีรอยฉีกขาดหรือชำรุดมีรูมาก่อน

                        </div>
                        <div class="readmorecondi mt-5 text-center">
                            <button class="btn btn-condition">ดาวน์โหลดคู่มือ
                                <span class="orangetext">คลิก</span> </butt>
                        </div>
                    </div>
                </div>
            </div>
            <div class="faqgroup mt-5">
                <div class="wrapper_pad">
                    <div class="row pt-4">
                        <div class="col">
                            <div class="titleTopic text-center">
                                <h5>คำถามที่พบบ่อยเกี่ยวกับ <span class="orangetext">ประกันภัยขนส่งสินค้า</span> </h5>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-5">
                        <div class="col">
                            <div class="accordion" id="accordionExample">
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingOne">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                            data-bs-target="#collapseOne" aria-expanded="true"
                                            aria-controls="collapseOne">
                                            <span>01</span> ท่านจะเลือกแผนความคุ้มครองอย่างไร?

                                        </button>
                                    </h2>
                                    <div id="collapseOne" class="accordion-collapse collapse show"
                                        aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            รถทุกชนิดที่จดทะเบียนกับกรมการขนส่งทางบก ไม่ว่าจะเป็นรถส่วนบุคคล รถโดยสาร
                                            รถบรรทุก รถราชการ รถบดถนน รถอีแต๋น รถพ่วง
                                            และรถที่ใช้พลังงานทางเลือกหรือพลังงานทดแทน ต้องทำประกันรถยนต์ภาคบังคับ
                                            (พ.ร.บ.) ทั้งหมด
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingTwo">
                                        <button class="accordion-button collapsed" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#collapseTwo"
                                            aria-expanded="false" aria-controls="collapseTwo">
                                            <span>02</span>
                                            หากธุรกิจของท่านไม่อยู่ในแผนความคุ้มครองการประกันธุรกิจปลอดภัยดังกล่าว
                                            สามารถทำประกันภัยได้หรือไม่?
                                        </button>
                                    </h2>
                                    <div id="collapseTwo" class="accordion-collapse collapse"
                                        aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            กรณีประสบอุบัติเหตุ ท่านสามารถติดศูนย์ลูกค้าสัมพันธ์วิริยะประกันภัย
                                            หมายเลขโทรศัพท์ 1557 ได้ตลอด 24 ชั่วโมง
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingThree">
                                        <button class="accordion-button collapsed" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#collapseThree"
                                            aria-expanded="false" aria-controls="collapseThree">
                                            <span>03</span> ท่านสามารถเรียกเงินชดเชยกรณีเสียชีวิตของผู้เอาประกันภัย
                                            สมาชิกในครอบครัว และพนักงาน ได้ต่อเมื่อ?
                                        </button>
                                    </h2>
                                    <div id="collapseThree" class="accordion-collapse collapse"
                                        aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            ตอบ สมาชิกในครอบครัว
                                            หรือพนักงานได้รับบาดเจ็บทางร่างกายอันเกิดจากอุบัติเหตุซึ่งเกิดขึ้นในสถานที่เอาประกันภัย
                                            จนต้องเสียชีวิตภายในสถานที่เอาประกันภัย
                                            หรือขณะนำส่งโรงพยาบาลที่มีสาเหตุหรือสืบเนื่องมาจาก
                                            1. ไฟไหม้
                                            2. ระเบิด
                                            3.
                                            การลักทรัพย์ซึ่งได้เข้าไปหรือออกจากสถานที่ที่เอาประกันภัยโดยการใช้กำลังอย่างรุนแรงและทำให้เกิดร่องรอยความเสียหายที่เห็นได้อย่างชัดเจน
                                            การชิงทรัพย์และปล้นทรัพย์
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <?php require('inc_footer.php'); ?>




</body>

</html>